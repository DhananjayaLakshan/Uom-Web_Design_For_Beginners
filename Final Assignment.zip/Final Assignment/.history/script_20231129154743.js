function book(){
    var item1 = document.getElementById("singleRoom");
    var item2 = document.getElementById("singlePrice");

    item1.style.color = 'red';
    item2.style.color = 'red';
}