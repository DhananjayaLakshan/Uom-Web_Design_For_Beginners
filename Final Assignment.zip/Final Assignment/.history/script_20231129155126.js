function book(){
    var item1 = document.getElementById("singleRoom");
    var item2 = document.getElementById("singlePrice");

    item1.style.color = 'red';
    item2.style.color = 'red';
}


function book2(){
    var item1 = document.getElementById("doubleRoom");
    var item2 = document.getElementById("doublePrice");

    item1.style.color = 'blue';
    item2.style.color = 'blue';
}

function book3(){
    var item1 = document.getElementById("familyRoom");
    var item2 = document.getElementById("familyPrice");

    item1.style.color = 'orange';
    item2.style.color = 'orange';
}

function book4(){
    var item1 = document.getElementById("luxuryRoom");
    var item2 = document.getElementById("luxuryPrice");

    item1.style.color = 'green';
    item2.style.color = 'green';
}

